-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Mer 25 Mai 2022 à 09:55
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `location`
--

-- --------------------------------------------------------

--
-- Structure de la table `categoriefilms`
--

CREATE TABLE IF NOT EXISTS `categoriefilms` (
  `codecat` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(45) NOT NULL,
  `comedie` varchar(45) NOT NULL,
  `avanture` varchar(45) NOT NULL,
  `drame` varchar(45) NOT NULL,
  `horreur` varchar(45) NOT NULL,
  `datecreation` date NOT NULL,
  `date_mise_jour` date NOT NULL,
  PRIMARY KEY (`codecat`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `categoriefilms`
--

INSERT INTO `categoriefilms` (`codecat`, `action`, `comedie`, `avanture`, `drame`, `horreur`, `datecreation`, `date_mise_jour`) VALUES
(1, 'action', 'comedi drame', 'aventure', 'drame', 'horrible', '2022-05-01', '2022-05-08'),
(2, 'revanche', 'aventure', 'drame', 'horriible', 'drame comedie', '2019-12-12', '2021-06-12'),
(3, 'arrivage', 'action comedie', 'aventure drame', 'horreur', 'action films', '2021-07-05', '2022-05-10'),
(4, 'mafia', 'aventure', 'horreur', 'action', 'drame aventure horreur', '1990-05-07', '2022-02-21'),
(5, 'mal', 'drame, aventure', 'drame', 'horeur et drame', 'aventure', '1999-08-08', '2022-03-08');

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `idclient` int(11) NOT NULL AUTO_INCREMENT,
  `nomclient` varchar(45) NOT NULL,
  `prenomclient` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `datecreation` date NOT NULL,
  `date_mise_jour` date NOT NULL,
  PRIMARY KEY (`idclient`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `clients`
--

INSERT INTO `clients` (`idclient`, `nomclient`, `prenomclient`, `email`, `datecreation`, `date_mise_jour`) VALUES
(1, 'MALICK ', 'Ba', 'malick@yahoo.fr', '2021-05-24', '2022-05-24'),
(2, 'GOMEZ', 'Gildas', 'bobos@yahoo.fr', '2021-05-22', '2022-05-22'),
(3, 'GNONIKE', 'Marie Claire', 'solim@gmail.com', '2022-05-24', '2022-05-24'),
(4, 'DUPONT', 'LaRievière', 'larive@gmail.com', '2019-03-24', '2020-10-18'),
(5, 'LAURE', 'Lapière', 'laure@gmail.com', '2017-09-17', '2022-05-15'),
(6, 'ADOSsOU', 'Albert', 'adalbert@gmail.com', '2011-06-12', '2021-01-01'),
(7, 'AWESSO', 'Aklaa', 'akla@gmail.com', '2021-09-05', '2022-05-01'),
(8, 'BATANA', 'Pinouwè', 'batanaipnet@gmail.com', '2022-05-01', '2022-05-24'),
(9, 'Marie', 'Claire', 'Claire@gmail.com', '2022-04-12', '2022-04-21');

-- --------------------------------------------------------

--
-- Structure de la table `films`
--

CREATE TABLE IF NOT EXISTS `films` (
  `codefilm` int(11) NOT NULL AUTO_INCREMENT,
  `titrefilm` varchar(50) NOT NULL,
  `datesortie` date NOT NULL,
  `duree` datetime NOT NULL,
  `realisateur` varchar(45) NOT NULL,
  `datecreation` date NOT NULL,
  `date_mise_jour` date NOT NULL,
  `codecat` int(11) NOT NULL,
  PRIMARY KEY (`codefilm`),
  KEY `codecat_idx` (`codecat`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Contenu de la table `films`
--

INSERT INTO `films` (`codefilm`, `titrefilm`, `datesortie`, `duree`, `realisateur`, `datecreation`, `date_mise_jour`, `codecat`) VALUES
(1, 'Lune de miel', '2021-12-12', '2021-12-12 01:23:52', 'inconu', '1999-04-21', '2002-03-04', 1),
(2, 'vaccance en amour', '2020-11-12', '2021-01-12 11:53:52', 'marvel', '2022-03-28', '2022-03-04', 1),
(3, 'l''avocat du diable', '1990-08-08', '2000-02-24 01:31:05', 'ciné', '1990-04-04', '2022-05-01', 5),
(4, 'EN_CAVALE', '1994-05-03', '1990-05-03 01:03:00', 'Third', '1991-02-03', '2003-01-07', 1),
(5, 'iles infernales', '2022-05-11', '2022-05-24 01:18:22', 'inconnu', '2021-03-14', '2022-05-01', 2),
(6, 'la créature du lac', '2021-01-01', '2022-04-24 01:25:16', 'cinémas', '2020-09-17', '2022-05-03', 5),
(7, 'le choc des empires', '2022-05-08', '2022-05-08 01:43:38', 'Nathalie', '2020-02-01', '2022-05-01', 3),
(8, 'une aventure d''un soir', '2019-05-24', '2022-05-10 01:19:26', 'Romances', '2019-08-12', '2021-10-05', 4),
(9, 'lapins crétains', '2021-01-12', '2021-05-12 01:25:10', 'marvel', '2000-04-21', '2002-03-04', 1),
(10, 'revanche', '2021-03-12', '2021-12-12 01:50:00', 'decor', '2012-04-21', '2021-03-04', 2);

-- --------------------------------------------------------

--
-- Structure de la table `louer`
--

CREATE TABLE IF NOT EXISTS `louer` (
  `idlouer` int(11) NOT NULL AUTO_INCREMENT,
  `datelocation` datetime NOT NULL,
  `dateretour` datetime NOT NULL,
  `codefilm` int(11) NOT NULL,
  `idclt` int(11) NOT NULL,
  PRIMARY KEY (`idlouer`),
  KEY `codefilm_idx` (`codefilm`),
  KEY `idclient` (`idclt`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Contenu de la table `louer`
--

INSERT INTO `louer` (`idlouer`, `datelocation`, `dateretour`, `codefilm`, `idclt`) VALUES
(1, '2022-05-02 00:02:01', '2022-05-25 00:00:00', 3, 3),
(2, '2022-05-01 02:00:00', '2022-05-31 00:00:00', 5, 1),
(3, '2020-03-16 00:00:00', '2020-10-02 13:22:16', 3, 6),
(4, '1990-05-23 05:13:07', '1990-05-28 04:36:29', 4, 4),
(5, '2022-05-18 10:34:45', '2022-05-27 03:15:16', 8, 6),
(6, '2022-01-19 10:19:19', '2022-01-11 07:22:26', 7, 1),
(7, '2020-07-14 02:06:10', '2021-04-19 15:27:09', 4, 1),
(8, '1880-02-12 19:20:08', '1990-02-12 05:16:19', 4, 1);

-- --------------------------------------------------------

--
-- Structure de la table `paiement`
--

CREATE TABLE IF NOT EXISTS `paiement` (
  `codepaiement` int(11) NOT NULL AUTO_INCREMENT,
  `datepaiement` date NOT NULL,
  `description` varchar(100) NOT NULL,
  `montant` float NOT NULL,
  `date_creation` date NOT NULL,
  `date_mise_jour` date NOT NULL,
  `idclient` int(11) NOT NULL,
  PRIMARY KEY (`codepaiement`),
  KEY `idclient_idx` (`idclient`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `paiement`
--

INSERT INTO `paiement` (`codepaiement`, `datepaiement`, `description`, `montant`, `date_creation`, `date_mise_jour`, `idclient`) VALUES
(1, '2022-02-06', 'première tranches en février dernier', 13000, '2021-08-15', '2022-01-02', 2),
(2, '2022-04-03', 'a payer la totalité de la sommes pour la locations de trois films différents', 300000, '2020-11-16', '2022-03-13', 3),
(3, '2022-05-22', 'troisième tranche', 12, '2022-01-03', '2022-03-14', 1),
(4, '2022-05-22', 'paiement de factures', 18.15, '2021-06-08', '2022-01-11', 4),
(5, '2022-05-16', 'location de films pour trois personnes', 100000, '1990-10-01', '2022-05-10', 5),
(6, '2022-05-07', 'location et paiement de la première tranches des frais', 300000, '1998-04-08', '2022-05-03', 6);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `films`
--
ALTER TABLE `films`
  ADD CONSTRAINT `codecat` FOREIGN KEY (`codecat`) REFERENCES `categoriefilms` (`codecat`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `louer`
--
ALTER TABLE `louer`
  ADD CONSTRAINT `idclt` FOREIGN KEY (`idclt`) REFERENCES `clients` (`idClient`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `codefilm` FOREIGN KEY (`codefilm`) REFERENCES `films` (`codefilm`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `paiement`
--
ALTER TABLE `paiement`
  ADD CONSTRAINT `idclient` FOREIGN KEY (`idclient`) REFERENCES `clients` (`idClient`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
